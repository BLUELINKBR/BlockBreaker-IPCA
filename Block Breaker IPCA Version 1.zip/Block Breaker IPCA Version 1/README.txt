BLOCK BREAKER IPCA Vers�o 1.0.0

Bem-vindo ao Block Breaker IPCA, o jogo de Block Breaker que te apresenta o Instituto Polit�cnico do C�vado e do Ave!

OBJETIVO: Quebre todos os blocos presentes em uma fase para progredir no jogo, e tente completar a fase final.
A cada fase ser� apresentado a um pr�dio novo do IPCA, tente conseguir a melhor pontua��o poss�vel!

COMANDOS:
Teclas direita e esquerda � Movem o bast�o pela tela
Bot�o Enter (start no controle) � Come�a o jogo na tela de t�tulo
Bot�o Esc (select no controle) � fecha o jogo e retorna ao Windows

SCORE:
Bloco Azul: 100 pontos ao ser destru�do. � necess�rio destruir todos para avan�ar para o pr�ximo n�vel.
Bloco Amarelo: 200 pontos ao ser destru�do. Se transforma em um Bloco Azul ap�s sua destrui��o (total de 300 pontos por Bloco).
Bloco Marrom: 300 pontos ao ser destru�do. Se transforma em um Bloco Amarelo ap�s sua destrui��o (total de 600 pontos por Bloco).
Bloco Vermelho: 400 pontos ao ser destru�do. Se transforma em um Bloco Marrom ap�s sua destrui��o (total de 1000 pontos por Bloco).
Vida Extra: se voc� conseguir completar o jogo, cada Vida Extra (de um m�ximo de 10) ir� render mil pontos para seu Score final.

Boa sorte e divirta-se!